import { createConnection } from "mysql";
let interval = 24 * 60 * 60 * 1000;
let employeesData = [
  {
    Employee_id: 1,
    Employee_Name: "john",
    Designation: "software developer",
    salary: 15000,
    joining_Date: "2005-11-12",
  },
  {
    Employee_id: 2,
    Employee_Name: "tomy",
    Designation: "tester",
    salary: 20000,
    joining_Date: "2000-1-1",
  },
  {
    Employee_id: 3,
    Employee_Name: "vishnu",
    Designation: "react developer",
    salary: 15000,
    joining_Date: "2010-4-14",
  },
  {
    Employee_id: 4,
    Employee_Name: "jafar",
    Designation: "data entry",
    salary: 20000,
    joining_Date: "2003-1-18",
  },
];
let count = 0;
var database = createConnection({
  host: "localhost",
  user: "root",
  password: "jijith",
  database: "MySql",
});

database.connect((err) => {
  if (err) console.log(err.message);
  let query = `CREATE DATABASE IF NOT EXISTS MySql`;
  database.query(query, (err) => {
    if (err) console.log(err.message);
  });

  let sqlQuery =
    "CREATE TABLE  IF NOT EXISTS Employee (Employee_id int, Employee_Name VARCHAR(255),Designation varchar(50),salary int,joining_Date DATE);";
  database.query(sqlQuery, (err) => {
    if (err) throw err;
  });
});
setInterval(() => {
  if (count === employeesData.length) {
    count = 0;
  }
  let sqlQuery = `INSERT INTO Employee (Employee_id , Employee_Name, Designation,salary,joining_Date)
     VALUES ('${employeesData[count].Employee_id}', '${employeesData[count].Employee_Name}','${employeesData[count].Designation}','${employeesData[count].salary}',
     '${employeesData[count].joining_Date}')`;
  database.query(sqlQuery, (err) => {
    if (err) throw err;
    console.log(`${count} record inserted`);
  });
  count = count + 1;
}, interval);
