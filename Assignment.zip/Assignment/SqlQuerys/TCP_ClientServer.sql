CREATE DATABASE IF NOT EXISTS TCP;
CREATE TABLE  IF NOT EXISTS TCP_ClientServer (ID int AUTO_INCREMENT not null PRIMARY KEY,Generated_Random_number int not null,Response_code varchar(10) not null);
INSERT INTO TCP_ClientServer  (Generated_Random_number,Response_code) VALUES (2,"odd");