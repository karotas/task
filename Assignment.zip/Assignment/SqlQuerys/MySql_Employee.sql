CREATE DATABASE IF NOT EXISTS MySql;
CREATE TABLE  IF NOT EXISTS Employee (Employee_id int, Employee_Name VARCHAR(255),Designation varchar(50),salary int,joining_Date DATE);
INSERT INTO Employee (Employee_id , Employee_Name, Designation,salary,joining_Date)
VALUES (1, 'john','tester',12000,'2000-1-11');