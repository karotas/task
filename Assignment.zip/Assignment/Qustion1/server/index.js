import { createConnection } from "mysql";
import express from "express";
import { Server } from "socket.io";
import http from "http";
import cors from "cors";
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "https://clientSite.com",
    methods: ["GET", "POST"],
  },
});
let port = 5000; // port number
app.use(cors());
// Connect to the database
var database = createConnection({
  host: "localhost",
  user: "root",
  password: "jijith",
  database: "TCP",
});

try {
  database.connect((err) => {
    if (err) throw err.message;

    let query = `CREATE DATABASE IF NOT EXISTS TCP`;

    database.query(query, (err) => {
      if (err) throw err.message;
    });

    let sqlQuery =
      "CREATE TABLE  IF NOT EXISTS TCP_ClientServer (ID int AUTO_INCREMENT not null PRIMARY KEY, Generated_Random_number int not null,Response_code varchar(10) not null);";
    database.query(sqlQuery, (err) => {
      if (err) throw err;
    });
  });
} catch (error) {
  console.log(error.message);
}

io.on("connection", (socket) => {
  console.log("a user connected");
  socket.on("disconnect", () => {
    console.log("user disconnected");
  });
  // Read data from the client
  socket.on("random number", (message) => {
    console.log("message: " + message);

    const even = "EVEN00";
    const odd = "ODD01";
    if (message) {
      // check the number is even or odd
      if (message % 2 === 0) {
        let sqlQuery = `INSERT INTO TCP_ClientServer  (Generated_Random_number,Response_code) VALUES ("${message}","${even}")`;
        // store data to the database
        database.query(sqlQuery, (err) => {
          if (err) throw err;
          io.emit("random number", even);
        });
        return;
      }
      var sqlQuery = `INSERT INTO TCP_ClientServer  (Generated_Random_number,Response_code) VALUES ("${message}","${odd}")`;
      database.query(sqlQuery, (err) => {
        if (err) throw err;
        io.emit("random number", odd);
      });
    }
  });
});
server.listen(port, () => console.log(`port running at ${port}`));
