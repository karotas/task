import { io } from "socket.io-client";
const URL = "http://localhost:5000";
const socket = io(URL);
setInterval(() => {
  let random = Math.floor(Math.random() * 10);
  socket.emit("random number", random);
}, 5000);
socket.on("random number", (message) => {
  console.log(message);
});
